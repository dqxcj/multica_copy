var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__02ojc~n._.js")
R.c("server/chunks/[root-of-the-server]__02oicn6._.js")
R.c("server/chunks/0t50_next_0b-abaw._.js")
R.c("server/chunks/02hg_apps_web__next-internal_server_app_robots_txt_route_actions_0iy15g7.js")
R.m(48142)
module.exports=R.m(48142).exports
