var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0o1_zbs._.js")
R.c("server/chunks/ssr/0t50_next_dist_esm_build_templates_app-page_015kuy2.js")
R.c("server/chunks/ssr/[root-of-the-server]__04da9e4._.js")
R.c("server/chunks/ssr/09e-__pnpm_0htz9ne._.js")
R.c("server/chunks/ssr/0t50_next_dist_client_components_builtin_global-error_0lhnr~e.js")
R.c("server/chunks/ssr/02hg_apps_web__next-internal_server_app__global-error_page_actions_12~7c7d.js")
R.m(20948)
module.exports=R.m(20948).exports
