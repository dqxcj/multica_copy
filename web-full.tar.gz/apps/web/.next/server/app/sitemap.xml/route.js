var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0rqz9x.._.js")
R.c("server/chunks/[root-of-the-server]__02oicn6._.js")
R.c("server/chunks/0t50_next_0b-abaw._.js")
R.c("server/chunks/02hg_apps_web__next-internal_server_app_sitemap_xml_route_actions_0sw1n06.js")
R.m(375026)
module.exports=R.m(375026).exports
