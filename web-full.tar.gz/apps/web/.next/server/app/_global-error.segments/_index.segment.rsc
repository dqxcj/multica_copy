1:"$Sreact.fragment"
2:I[991617,["/_next/static/chunks/0r8kf7m727p~7.js","/_next/static/chunks/0xc-6dktdqhvp.js"],"default"]
3:I[958033,["/_next/static/chunks/0r8kf7m727p~7.js","/_next/static/chunks/0xc-6dktdqhvp.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"CCRW2BlCzuz_uDCS02gq4"}
