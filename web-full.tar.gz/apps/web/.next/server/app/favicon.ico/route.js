var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__0.nfco2._.js")
R.c("server/chunks/[root-of-the-server]__02oicn6._.js")
R.c("server/chunks/02hg_apps_web__next-internal_server_app_favicon_ico_route_actions_0lr0p70.js")
R.m(283250)
module.exports=R.m(283250).exports
