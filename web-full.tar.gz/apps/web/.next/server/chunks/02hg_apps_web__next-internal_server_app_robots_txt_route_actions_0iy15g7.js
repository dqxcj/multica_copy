module.exports=[951748,s=>{"use strict";s.s([])}];

//# sourceMappingURL=02hg_apps_web__next-internal_server_app_robots_txt_route_actions_0iy15g7.js.map