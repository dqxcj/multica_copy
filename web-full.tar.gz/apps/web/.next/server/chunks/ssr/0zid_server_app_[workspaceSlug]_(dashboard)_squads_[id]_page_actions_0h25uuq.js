module.exports=[838679,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0zid_server_app_%5BworkspaceSlug%5D_%28dashboard%29_squads_%5Bid%5D_page_actions_0h25uuq.js.map