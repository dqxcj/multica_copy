module.exports=[194922,a=>{"use strict";a.s([])}];

//# sourceMappingURL=02hg_apps_web__next-internal_server_app_%28landing%29_contact-sales_page_actions_0rf956d.js.map