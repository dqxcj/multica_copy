module.exports=[853665,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0zqt_next-internal_server_app_%5BworkspaceSlug%5D_%28dashboard%29_inbox_page_actions_0df2eo0.js.map