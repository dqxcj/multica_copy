module.exports=[236530,a=>a.a(async(b,c)=>{try{var d=a.i(36375),e=a.i(353851),f=a.i(764902),g=a.i(336107),h=b([f,g]);[f,g]=h.then?(await h)():h,a.s(["default",0,function({params:a}){let{id:b}=(0,e.use)(a);return(0,d.jsx)(g.ProjectDetail,{projectId:b})}]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=02hg_apps_web_app_%5BworkspaceSlug%5D_%28dashboard%29_projects_%5Bid%5D_page_tsx_0_.pwkb._.js.map