module.exports=[163328,a=>{"use strict";var b=a.i(809734),c=a.i(430894);a.s(["useAttachmentHtmlText",0,function(a){return(0,b.useQuery)({queryKey:["attachment-content",a??""],queryFn:()=>c.api.getAttachmentTextContent(a),enabled:!!a,retry:!1,staleTime:3e5,gcTime:18e5})}])},332595,a=>{"use strict";let b=`<script>
(function(){
  document.addEventListener('click', function(e) {
    if (e.defaultPrevented) return;
    var t = e.target;
    if (!t || typeof t.closest !== 'function') return;
    var a = t.closest('a[href]');
    if (!a) return;
    var href = a.getAttribute('href');
    if (!href || href.charAt(0) !== '#' || href === '#') return;
    var id;
    try { id = decodeURIComponent(href.slice(1)); } catch (_) { return; }
    if (!id) return;
    var dest = document.getElementById(id);
    if (!dest && typeof CSS !== 'undefined' && CSS.escape) {
      dest = document.querySelector('a[name="' + CSS.escape(id) + '"]');
    }
    if (!dest) return;
    e.preventDefault();
    dest.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
})();
</script>`;a.s(["withFragmentNavShim",0,function(a){return(a??"")+b}])},637938,a=>{"use strict";var b=a.i(36375),c=a.i(353851),d=a.i(557443);let e={error:null};class f extends c.Component{state=e;static getDerivedStateFromError(a){return{error:a}}componentDidCatch(a,b){this.props.onError?.(a,b),console.error("ErrorBoundary caught:",a,b.componentStack)}componentDidUpdate(a){if(null==this.state.error)return;let b=a.resetKeys,c=this.props.resetKeys;if(b&&c){if(b.length!==c.length)return void this.reset();for(let a=0;a<b.length;a++)if(!Object.is(b[a],c[a]))return void this.reset()}}reset=()=>{this.setState(e)};render(){let{error:a}=this.state;return null==a?this.props.children:this.props.fallback?this.props.fallback({error:a,reset:this.reset}):(0,b.jsx)(g,{error:a,reset:this.reset})}}function g({error:a,reset:c}){return(0,b.jsxs)("div",{role:"alert",className:"flex flex-col items-start gap-3 rounded-md border border-dashed border-border bg-muted/30 p-4 text-sm",children:[(0,b.jsxs)("div",{className:"space-y-1",children:[(0,b.jsx)("p",{className:"font-medium text-foreground",children:"Something went wrong displaying this section."}),(0,b.jsx)("p",{className:"text-muted-foreground",children:a.message||"An unexpected error occurred."})]}),(0,b.jsx)(d.Button,{size:"sm",variant:"outline",onClick:c,children:"Try again"})]})}a.s(["ErrorBoundary",0,f])},719571,a=>{"use strict";var b=a.i(36375),c=a.i(353851),d=a.i(295997);a.i(914311);var e=a.i(482726),f=a.i(163328),g=a.i(332595);function h({attachmentId:a,filename:d}){let{t:i}=(0,e.useT)("editor"),j=(0,f.useAttachmentHtmlText)(a);(0,c.useEffect)(()=>{d&&(document.title=d)},[d]);let k=j.data?.text,l=j.isLoading,m=!l&&(!!j.error||!k);return(0,b.jsx)("div",{className:"flex h-full w-full flex-col bg-background",children:l?(0,b.jsx)("div",{className:"flex flex-1 items-center justify-center text-sm text-muted-foreground",children:i(a=>a.attachment.preview_loading)}):m?(0,b.jsx)("div",{className:"flex flex-1 items-center justify-center px-4 text-sm text-muted-foreground","data-testid":"attachment-preview-page-error",children:i(a=>a.attachment.preview_failed)}):(0,b.jsx)("iframe",{srcDoc:(0,g.withFragmentNavShim)(k),sandbox:"allow-scripts",title:d??"HTML attachment",className:"flex-1 w-full border-0 bg-background"})})}var i=a.i(637938);a.s(["default",0,function({params:a}){let{id:e}=(0,c.use)(a),f=(0,d.useSearchParams)().get("name")??void 0;return(0,b.jsx)(i.ErrorBoundary,{resetKeys:[e],children:(0,b.jsx)(h,{attachmentId:e,filename:f})})}],719571)}];

//# sourceMappingURL=_worktrees_runtime-config_00lkr-g._.js.map