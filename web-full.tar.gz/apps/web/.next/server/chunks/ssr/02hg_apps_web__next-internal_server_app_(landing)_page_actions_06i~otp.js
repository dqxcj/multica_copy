module.exports=[697716,a=>{"use strict";a.s([])}];

//# sourceMappingURL=02hg_apps_web__next-internal_server_app_%28landing%29_page_actions_06i~otp.js.map