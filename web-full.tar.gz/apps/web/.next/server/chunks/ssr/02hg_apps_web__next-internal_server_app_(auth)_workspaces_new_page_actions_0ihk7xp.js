module.exports=[587451,a=>{"use strict";a.s([])}];

//# sourceMappingURL=02hg_apps_web__next-internal_server_app_%28auth%29_workspaces_new_page_actions_0ihk7xp.js.map