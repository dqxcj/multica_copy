module.exports=[586578,a=>{"use strict";a.s([])}];

//# sourceMappingURL=02hg_apps_web__next-internal_server_app_%28landing%29_changelog_page_actions_116zt-7.js.map