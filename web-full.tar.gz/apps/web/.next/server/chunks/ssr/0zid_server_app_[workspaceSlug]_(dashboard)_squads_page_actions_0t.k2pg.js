module.exports=[621921,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0zid_server_app_%5BworkspaceSlug%5D_%28dashboard%29_squads_page_actions_0t.k2pg.js.map