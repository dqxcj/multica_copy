module.exports=[874582,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0zid_server_app_%5BworkspaceSlug%5D_%28dashboard%29_issues_%5Bid%5D_page_actions_0qjfffb.js.map