module.exports=[115965,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0zid_server_app_%5BworkspaceSlug%5D_%28dashboard%29_my-issues_page_actions_131z41e.js.map