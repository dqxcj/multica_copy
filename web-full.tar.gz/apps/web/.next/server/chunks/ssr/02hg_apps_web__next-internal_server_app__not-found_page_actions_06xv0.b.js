module.exports=[663958,a=>{"use strict";a.s([])}];

//# sourceMappingURL=02hg_apps_web__next-internal_server_app__not-found_page_actions_06xv0.b.js.map