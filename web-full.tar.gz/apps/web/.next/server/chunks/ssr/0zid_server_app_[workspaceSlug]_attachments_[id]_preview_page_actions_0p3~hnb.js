module.exports=[227896,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0zid_server_app_%5BworkspaceSlug%5D_attachments_%5Bid%5D_preview_page_actions_0p3~hnb.js.map