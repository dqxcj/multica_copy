module.exports=[403695,a=>{"use strict";var b=a.i(36375),c=a.i(353851),d=a.i(809734),e=a.i(295997);a.i(601564);var f=a.i(208269),g=a.i(528849);a.i(669893);var h=a.i(34619);a.i(610750);var i=a.i(962747),j=a.i(479427),k=a.i(557443);a.i(558614);var l=a.i(190775);a.i(585061);var m=a.i(946297);a.i(827537);var n=a.i(989543);a.i(914311);var o=a.i(482726);function p(){let{t:a}=(0,o.useT)("workspace"),d=(0,l.useNavigation)(),e=(0,m.useLogout)();return(0,c.useEffect)(()=>{"u">typeof document&&(document.cookie="last_workspace_slug=; path=/; max-age=0; SameSite=Lax")},[]),(0,b.jsxs)("div",{className:"flex min-h-svh flex-col",children:[(0,b.jsx)(n.DragStrip,{}),(0,b.jsxs)("div",{className:"flex flex-1 flex-col items-center justify-center gap-6 px-6 pb-12 text-center",children:[(0,b.jsxs)("div",{className:"space-y-2",children:[(0,b.jsx)("h1",{className:"text-2xl font-semibold tracking-tight",children:a(a=>a.no_access.title)}),(0,b.jsx)("p",{className:"max-w-md text-muted-foreground",children:a(a=>a.no_access.description)})]}),(0,b.jsxs)("div",{className:"flex flex-col gap-2 sm:flex-row",children:[(0,b.jsx)(k.Button,{onClick:()=>d.push(g.paths.root()),children:a(a=>a.no_access.go_to_workspaces)}),(0,b.jsx)(k.Button,{variant:"outline",onClick:e,children:a(a=>a.no_access.sign_in_different)})]})]})]})}var q=a.i(790482),r=a.i(425837),s=a.i(896743),t=a.i(430894);a.i(524426);var u=a.i(593727),v=a.i(329700),w=a.i(164199),x=a.i(379523);function y(a){return"string"==typeof a?a.trim():""}let z={en:`You are Multica Helper, the built-in AI assistant for this Multica workspace. Your role is to help any member use Multica better — answer questions, give advice, and execute workspace operations on their behalf.

## What Multica is

Multica is an open-source, AI-native team workspace (source: https://github.com/multica-ai/multica). The core idea: AI agents are treated as real teammates — they get assigned issues on a kanban-style board, comment in threads, change status, and run code, exactly like human members. You can also chat directly with agents (chat), group them into squads, and run scheduled or triggered automation (autopilot).

For concept details (workspace / issue / project / agent / runtime / skill / squad / autopilot / inbox / chat session): fetch https://multica.ai/docs via WebFetch — that's authoritative. For the "why" or implementation, fetch the GitHub repo above. Never paraphrase concepts from memory.

For ANY product-usage problem the user runs into (bug, unclear behavior, missing feature, improvement idea), suggest they file an issue at https://github.com/multica-ai/multica/issues — that's the official feedback channel.

## What you can do

Your toolbox is the \`multica\` CLI. It's already on your PATH and authenticated as the workspace owner.

Your full capability surface = whatever \`multica --help\` shows. Run \`multica --help\` first, then \`multica <command> --help\` for any subcommand; use \`--output json\` for structured data. The CLI is your manifest — never invent commands or flags.

A few things you can actually do (non-exhaustive — \`--help\` is the source of truth):
- Create issues, post comments
- Create or iterate on agents
- Manage projects, squads, autopilots, skills, runtimes, etc.

## Tone

Be concise and direct, like a colleague. Respond in the user's language (Chinese in, Chinese out). When pointing at a UI location, name the exact path ("Settings → Agents → New"); when pointing at a doc, link to the specific page, not the homepage. Never fabricate URLs, flags, or file paths.

## Stay current

If you notice \`multica --help\`, the docs, or the GitHub repo contradict or meaningfully extend this instruction — renamed commands, new core concepts, removed flags — surface it to the user and propose an updated version of your own instruction before continuing. Do not silently update your instructions; wait for the user's confirmation, then apply the change via the CLI.`,zh:`你是 Multica Helper,这个 Multica workspace 内置的 AI 助手。你的角色是帮助任何成员更好地使用 Multica —— 回答问题、给出建议、代为执行 workspace 操作。

## Multica 是什么

Multica 是一个开源、AI 原生的团队工作区(源码:https://github.com/multica-ai/multica)。核心思想:AI agent 被当作真正的队友 —— 在看板上被分派 issue、在讨论里发评论、修改状态、运行代码,与人类成员完全一样。你也可以直接和 agent 聊天(chat),把它们组合成小队(squad),运行定时或事件触发的自动化(autopilot)。

概念细节(workspace / issue / project / agent / runtime / skill / squad / autopilot / inbox / chat session)请用 WebFetch 抓取 https://multica.ai/docs —— 那是权威来源。关于"为什么"或实现细节,请抓取上面 GitHub 仓库。不要凭记忆复述概念。

任何产品使用问题(bug、行为不清晰、缺少功能、改进建议),建议用户去 https://github.com/multica-ai/multica/issues 开 issue —— 那是官方反馈渠道。

## 你能做什么

你的工具箱是 \`multica\` CLI。它已经在你的 PATH 上,以 workspace owner 身份认证。

你的全部能力 = \`multica --help\` 显示的内容。先跑 \`multica --help\`,再跑 \`multica <command> --help\` 看子命令;用 \`--output json\` 拿结构化数据。CLI 是你的清单 —— 不要编造命令或参数。

几件你确实能做的事(不完全列举 —— \`--help\` 是权威):
- 创建 issue、发评论
- 创建或迭代 agent
- 管理 project、squad、autopilot、skill、runtime 等

## 语气

像同事一样,简洁、直接。用用户的语言回复(中文进,中文出)。指向 UI 位置时给出精确路径(如 "Settings → Agents → New");指向文档时链接到具体页面,而不是首页。绝不编造 URL、参数或文件路径。

## 保持同步

如果你发现 \`multica --help\`、官方文档或 GitHub 仓库出现与本 instruction 相冲突或重要补充的变化(命令改名、新增核心概念、删除参数),先告诉用户、提议一份更新后的 instruction,然后再继续。不要静默地改自己的 instruction;等用户确认,再通过 CLI 应用变更。`},A={en:"Multica usage assistant. Ask how to use it, help create/view tasks, configure agents, and more.",zh:"Multica 使用助手。可以询问用法、帮助创建/查看任务、配置 agent 等。"},B="Multica Helper",C={en:"Step 2 — Create your first Multica Agent",zh:"第 2 步 —— 创建你的第一个 Multica Agent"},D={en:"Step 1 — Connect a runtime to start using agents",zh:"第 1 步 —— 连接运行时,开始使用 agent"},E={en:`Welcome to Multica.

Agents need a runtime before they can execute work. You can still use Multica as a lightweight project-management workspace while you install one.

## Try Multica first

Before the runtime is ready, you can:

1. Create a project for your current work.
2. Create a few issues and move them across backlog, todo, in_progress, and done.
3. Add priorities, labels, comments, and subscriptions.
4. Use Inbox to track assignments and mentions.

That gives you the project-management layer first. Once a runtime is connected, agents can start working from the same issues.

## Install your first agent runtime

Full guide: https://multica.ai/docs/install-agent-runtime

For English users, the fastest first path is Codex:

1. Make sure Node.js is installed.
2. Install Codex:
   npm i -g @openai/codex
3. Sign in:
   codex
4. Confirm your terminal can find it:
   which codex
   codex --version
5. Restart the Multica daemon:
   multica daemon restart
   If you use the desktop app, restarting the app is enough.
6. Return to Runtimes and refresh. You should see a Codex runtime online.
7. Create your first agent from that runtime, then assign an issue to the agent and set status to todo.

Codex reference: https://developers.openai.com/codex/cli

When the runtime is connected, you can create Multica Helper for a guided first run.`,zh:`欢迎来到 Multica。

智能体需要先连上运行时才能执行工作。运行时还没准备好时,你也可以先把 Multica 当作轻量项目管理工具体验起来。

## 先体验项目管理功能

运行时安装前,你可以先做这些事:

1. 为当前工作创建一个项目。
2. 新建几个 issue,并在 backlog、todo、in_progress、done 之间流转。
3. 给 issue 加优先级、标签、评论和订阅。
4. 用收件箱追踪分配给你的事项和 @mention。

这样你先熟悉项目管理层。连上运行时后,智能体会直接在这些 issue 上开始工作。

## 安装第一个 Agent 运行时

完整文档:https://multica.ai/docs/install-agent-runtime

中文用户建议先装 Kimi CLI:

1. 在 macOS / Linux 终端安装 Kimi CLI:
   curl -LsSf https://code.kimi.com/install.sh | bash
   Windows PowerShell:
   Invoke-RestMethod https://code.kimi.com/install.ps1 | Invoke-Expression
2. 确认终端能找到 Kimi:
   kimi --version
3. 在你想让 Kimi 工作的项目目录里启动一次:
   kimi
4. 首次启动后输入 /login,按提示完成 Kimi Code 或 API key 配置。
5. 重启 Multica 守护进程:
   multica daemon restart
   如果你用桌面端,重启 app 即可。
6. 回到 Runtimes 页面刷新。你应该能看到一个在线的 Kimi 运行时。
7. 用这个运行时创建第一个智能体,再把一个 issue 分配给它,并把状态切到 todo。

Kimi CLI 官方文档:https://moonshotai.github.io/kimi-cli/zh/guides/getting-started.html

运行时连上后,你就可以创建 Multica Helper,开始一次有智能体参与的上手引导。`},F={en:"Your next step:",zh:"完成后的下一步："},G=["intro","tour","welcome_page"],H={intro:{title:{en:"Introduce Multica to me",zh:"简单介绍一下 Multica"},prompt:{en:"Introduce Multica to me in 1–2 paragraphs. Cover what it is, the core concepts (workspace / issue / agent / runtime), and how it differs from tools like Linear or Jira.",zh:"用 1-2 段话简单介绍 Multica 给我。讲清楚它是什么、核心概念有哪些(workspace / issue / agent / runtime)、和 Linear / Jira 之类的工具核心区别在哪。"}},tour:{title:{en:"Walk me through the core features",zh:"带我熟悉每个功能"},prompt:{en:"Walk me through Multica's core features — issue, agent, squad, autopilot, chat. Pick one realistic scenario I might run into and explain how all these pieces fit together.",zh:"陪我熟悉 Multica 的每个核心功能 —— issue、agent、squad、autopilot、chat。挑一个我可能用得上的真实场景,讲讲这几个东西是怎么配合的。"}},welcome_page:{title:{en:"Show me what Multica can do for me — as slides",zh:"用 slides 介绍 Multica 能为我做什么"},prompt:{en:`Build me a single-file HTML slide deck that shows what Multica can do for me. Tailor it to my role and use case (see "About me" below). Paste the FULL HTML in a fenced \`\`\`html block in a comment on this issue so I can copy it straight out, save as \`multica-intro.html\`, and double-click to open it in a browser.

**Format**
- One self-contained .html, all CSS / JS inline. Zero dependencies, no build tools, no external images (use CSS-generated visuals — gradients, geometric shapes, SVG inline).
- 5–8 slides total:
  1. Title — "What Multica can do for [my role]"
  2. Four core concepts — workspace / issue / agent / runtime, one slide
  3–6. 3–4 concrete scenarios tailored to my use case, each in the form "When you want X → here's how Multica handles it"
  7. Closing — one specific next-step action

**Viewport rules (non-negotiable)**
- Every \`.slide\`: \`height: 100vh; height: 100dvh; overflow: hidden;\`
- All font-size and spacing values use \`clamp(min, preferred, max)\` — never fixed px / rem.
- Density per slide: 1 heading + ≤ 4 bullets, OR 1 heading + 2 short paragraphs. Overflow → split into another slide.
- Respect \`prefers-reduced-motion: reduce\` (disable animations).

**Aesthetic (avoid the AI-slop look)**
- Pick a distinctive typeface from Fontshare or Google Fonts. Do NOT use Inter, Roboto, Arial, or system fonts.
- Commit to a cohesive palette via CSS variables: one dominant color + one sharp accent. Avoid the clich\xe9 "purple gradient on white".
- Backgrounds: layered gradients or geometric patterns for atmosphere — never flat white.
- Animation: ONE well-orchestrated load-in per slide using staggered \`animation-delay\`. CSS-only. No scattered micro-interactions.

**Navigation**
- ArrowLeft / ArrowRight and Space to advance. Small page indicator in a corner.

When done, also reply with a one-sentence summary of which scenarios you picked for me and why.`,zh:`给我做一份单文件 HTML 演示稿,介绍 Multica 能为我做什么。根据我的角色和使用场景定制(见下面"关于我")。把完整 HTML 贴到这条 issue 的评论里的 \`\`\`html 代码块中,我直接复制下来存成 \`multica-intro.html\` 双击就能在浏览器里打开。

**产出格式**
- 一个自包含 .html,CSS / JS 全部 inline。零依赖、不用打包、不引外部图片(视觉用纯 CSS 生成 —— 渐变、几何形状、内联 SVG)。
- 5-8 张 slide:
  1. 标题页 —— "Multica 能为 [我的角色] 做什么"
  2. 四个核心概念 —— workspace / issue / agent / runtime,一张
  3-6. 3-4 个针对我使用场景的具体例子,形如"当你想做 X → Multica 是这样处理的"
  7. 收尾页 —— 一个具体的下一步动作

**视口约束(必须遵守)**
- 每个 \`.slide\`:\`height: 100vh; height: 100dvh; overflow: hidden;\`
- 所有 font-size 和 spacing 用 \`clamp(min, preferred, max)\`,不要写死 px / rem。
- 每张密度:1 个标题 + ≤ 4 个 bullet,或 1 个标题 + 2 段短段。超出就拆下一张。
- 兼容 \`prefers-reduced-motion: reduce\`(关动画)。

**审美(避免 AI 套路感)**
- 字体从 Fontshare 或 Google Fonts 选一个有辨识度的,不要用 Inter / Roboto / Arial / 系统字体。
- 用 CSS 变量统一调色板:一个主色 + 一个锐利的强调色。避免烂大街的"紫色渐变 + 白底"。
- 背景用层叠渐变或几何图案带氛围,不要纯白。
- 每张 slide 一次性的有节奏入场动画(用 \`animation-delay\` 错峰),CSS 实现。不要散落的微动效。

**导航**
- 左右方向键和空格切换,角落放一个小的页码指示。

做完后再用一句话告诉我你为我挑了哪几个场景以及为什么。`}}};function I(a){return a&&a.toLowerCase().startsWith("zh")?"zh":"en"}function J(){let a=(0,j.useAuthStore)(a=>a.user),c=(0,f.useCurrentWorkspace)(),d=(0,u.useWelcomeStore)(a=>a.signal),e=(0,u.useWelcomeStore)(a=>a.dismissed),g=(0,u.useWelcomeStore)(a=>a.dismiss);return a&&d&&!e&&c&&c.id===d.workspaceId?"runtime"===d.choice&&d.runtimeId?(0,b.jsx)(R,{workspaceId:d.workspaceId,runtimeId:d.runtimeId,onAbandon:g,onComplete:g}):"skip"===d.choice?(0,b.jsx)(S,{workspaceId:d.workspaceId,onDismiss:g}):null:null}let K="Multica Helper",L="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 128'%3E%3Cdefs%3E%3ClinearGradient id='t' x1='0' y1='0' x2='0' y2='1'%3E%3Cstop offset='0%25' stop-color='%2323242C'/%3E%3Cstop offset='100%25' stop-color='%2313141A'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='128' height='128' rx='28' fill='url(%23t)'/%3E%3Cg stroke='%23FFFFFF' stroke-width='13' stroke-linecap='round'%3E%3Cline x1='64' y1='32' x2='64' y2='96'/%3E%3Cline x1='32' y1='64' x2='96' y2='64'/%3E%3Cline x1='41.4' y1='41.4' x2='86.6' y2='86.6'/%3E%3Cline x1='86.6' y1='41.4' x2='41.4' y2='86.6'/%3E%3C/g%3E%3C/svg%3E",M=new Map;async function N(a,b,c){let d=`${a}:${b}`,e=M.get(d);if(e)return e;let f=(async()=>{let d=(await t.api.listAgents({workspace_id:a})).find(a=>a.name===K&&"workspace"===a.visibility&&!a.archived_at);if(d)return d;let e=I(c);return t.api.createAgent({name:K,description:A[e],instructions:z[e],avatar_url:L,runtime_id:b,visibility:"workspace",max_concurrent_tasks:6,template:"multica_helper"})})();return M.set(d,f),f.finally(()=>{M.get(d)===f&&M.delete(d)}).catch(()=>{}),f}let O=new Map;function P(a,b){let c=O.get(a);if(c)return c;let d=t.api.createIssue(b);return O.set(a,d),d.finally(()=>{O.get(a)===d&&O.delete(a)}).catch(()=>{}),d}let Q=new Map;function R({workspaceId:a,runtimeId:d,onAbandon:e,onComplete:f}){let{t:i,i18n:m}=(0,o.useT)("onboarding"),n=(0,l.useNavigation)(),p=(0,q.useQueryClient)(),r=(0,j.useAuthStore)(a=>a.user),[u,z]=(0,c.useState)(null),[A,B]=(0,c.useState)(null),[C,D]=(0,c.useState)(0),[E,F]=(0,c.useState)(()=>new Set),[J,K]=(0,c.useState)(!1),[M,O]=(0,c.useState)(null),P=(0,c.useRef)(!1),[Q,S]=(0,c.useState)(null),T=(0,c.useMemo)(()=>{let a=I(m.language);return{heading:i(a=>a.welcome_after_onboarding.user_context_heading),roleLabel:i(a=>a.welcome_after_onboarding.user_context_role_label),useCaseLabel:i(a=>a.welcome_after_onboarding.user_context_use_case_label),listSeparator:"zh"===a?"、":", ",role:{engineer:i(a=>a.questions.role.engineer),product:i(a=>a.questions.role.product),designer:i(a=>a.questions.role.designer),founder:i(a=>a.questions.role.founder),marketing:i(a=>a.questions.role.marketing),writer:i(a=>a.questions.role.writer),research:i(a=>a.questions.role.research),ops:i(a=>a.questions.role.ops),student:i(a=>a.questions.role.student),other:i(a=>a.questions.role.other)},useCase:{ship_code:i(a=>a.questions.use_case.ship_code),manage_team:i(a=>a.questions.use_case.manage_team),personal_tasks:i(a=>a.questions.use_case.personal_tasks),plan_research:i(a=>a.questions.use_case.plan_research),write_publish:i(a=>a.questions.use_case.write_publish),automate_ops:i(a=>a.questions.use_case.automate_ops),evaluate:i(a=>a.questions.use_case.evaluate),other:i(a=>a.questions.use_case.other)}}},[i,m.language]);if((0,c.useEffect)(()=>{if(u)return;let b=!1;return(async()=>{try{let c=await N(a,d,m.language);b||(z(c),p.invalidateQueries({queryKey:h.workspaceKeys.agents(a)}))}catch(a){b||B(a instanceof Error?a:Error(String(a)))}})(),()=>{b=!0}},[u,C,m.language,p,d,a]),A)return(0,b.jsx)(V,{title:i(a=>a.welcome_after_onboarding.error_title),message:A.message||i(a=>a.welcome_after_onboarding.error_generic),retryLabel:i(a=>a.welcome_after_onboarding.retry),closeLabel:i(a=>a.welcome_after_onboarding.error_close),onRetry:()=>{B(null),D(a=>a+1)},onClose:e});if(!u)return(0,b.jsx)(U,{label:i(a=>a.welcome_after_onboarding.loading_helper)});let X=I(m.language),Y=async()=>{if(!P.current&&0!==E.size){P.current=!0,O(null),K(!0);try{let b=function(a,b){var c;if(!a)return"";let d=y(a.role),e=y(a.role_other),f="other"===d?e:d?b.role[d]??d:"",g=Array.isArray(c=a.use_case)?c.filter(a=>"string"==typeof a&&a.length>0):"string"==typeof c&&c.length>0?[c]:[],h=y(a.use_case_other),i=g.map(a=>"other"===a?h:b.useCase[a]??a).filter(a=>a.length>0),j=f.length>0,k=i.length>0;if(!j&&!k)return"";let l=["","","---","",`> **${b.heading}**`,">"];return j&&l.push(`> ${b.roleLabel}: ${f}`),k&&l.push(`> ${b.useCaseLabel}: ${i.join(b.listSeparator)}`),l.join("\n")}(r?.onboarding_questionnaire,T),c=G.filter(a=>E.has(a)),d=await Promise.all(c.map(a=>{let c=H[a];return t.api.createIssue({title:c.title[X],description:c.prompt[X]+b,status:"todo",priority:"high",assignee_type:"agent",assignee_id:u.id})}));await Promise.all([p.invalidateQueries({queryKey:v.issueKeys.all(a)}),p.invalidateQueries({queryKey:h.workspaceKeys.agents(a)})]),P.current=!1,K(!1),S(d[0].id)}catch(a){P.current=!1,K(!1),O(a instanceof Error?a.message:i(a=>a.welcome_after_onboarding.error_generic))}}},Z=async()=>{if(!Q)return;f();let b=await W(p,a);n.push(g.paths.workspace(b).issueDetail(Q))};return Q?(0,b.jsx)(w.Dialog,{open:!0,modal:!0,disablePointerDismissal:!0,onOpenChange:()=>{},children:(0,b.jsxs)(w.DialogContent,{showCloseButton:!1,className:"max-w-md sm:max-w-md","aria-describedby":"welcome-after-onboarding-runtime-success-subtitle",children:[(0,b.jsxs)("div",{className:"flex flex-col items-center gap-3 pt-4",children:[(0,b.jsx)("div",{className:"text-4xl animate-welcome-emoji-pop","aria-hidden":!0,children:"🎉"}),(0,b.jsx)(w.DialogTitle,{className:"text-center text-2xl font-semibold",children:i(a=>a.welcome_after_onboarding.runtime.success.title)}),(0,b.jsx)(w.DialogDescription,{id:"welcome-after-onboarding-runtime-success-subtitle",className:"text-center text-sm text-muted-foreground",children:i(a=>a.welcome_after_onboarding.runtime.success.subtitle,{agentName:u.name})}),(0,b.jsxs)("div",{className:"mt-1 flex flex-col gap-1.5 max-w-sm",children:[(0,b.jsx)("p",{className:"text-center text-xs text-muted-foreground/80 leading-relaxed",children:i(a=>a.welcome_after_onboarding.runtime.success.tip_inbox)}),(0,b.jsx)("p",{className:"text-center text-xs text-muted-foreground/80 leading-relaxed",children:i(a=>a.welcome_after_onboarding.runtime.success.tip_chat)})]})]}),(0,b.jsx)("div",{className:"mt-4 flex justify-end",children:(0,b.jsx)(k.Button,{size:"lg",onClick:Z,children:i(a=>a.welcome_after_onboarding.runtime.success.got_it)})})]})}):(0,b.jsx)(w.Dialog,{open:!0,modal:!0,disablePointerDismissal:!0,onOpenChange:()=>{},children:(0,b.jsxs)(w.DialogContent,{showCloseButton:!1,className:"max-w-xl sm:max-w-xl","aria-describedby":"welcome-after-onboarding-runtime-subtitle",children:[(0,b.jsxs)("div",{className:"flex flex-col items-center gap-3 pt-4 animate-onboarding-enter",children:[(0,b.jsx)("img",{src:u.avatar_url||L,alt:"","aria-hidden":!0,className:"h-14 w-14 rounded-xl ring-1 ring-foreground/10"}),(0,b.jsx)(w.DialogTitle,{className:"text-center text-xl font-semibold",children:i(a=>a.welcome_after_onboarding.runtime.greeting)}),(0,b.jsx)(w.DialogDescription,{id:"welcome-after-onboarding-runtime-subtitle",className:"text-center text-sm text-muted-foreground",children:i(a=>a.welcome_after_onboarding.runtime.subtitle)}),(0,b.jsx)("p",{className:"text-center text-sm text-muted-foreground max-w-md leading-relaxed",children:i(a=>a.welcome_after_onboarding.runtime.capabilities)})]}),(0,b.jsxs)("div",{className:"mt-4 border-t pt-4",children:[(0,b.jsx)("p",{className:"mb-3 text-sm font-medium text-foreground",children:i(a=>a.welcome_after_onboarding.runtime.section_label)}),(0,b.jsx)("div",{className:"flex flex-col gap-2",children:G.map(a=>{let c=E.has(a);return(0,b.jsx)("button",{type:"button",onClick:()=>{!J&&F(b=>{let c=new Set(b);return c.has(a)?c.delete(a):c.add(a),c})},disabled:J,"aria-pressed":c,className:(0,x.cn)("flex items-start gap-3 rounded-lg border bg-card px-3 py-2.5 text-left transition-colors",c?"border-primary ring-1 ring-primary":"hover:border-foreground/20","disabled:cursor-not-allowed disabled:opacity-60"),children:(0,b.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,b.jsx)("p",{className:"text-sm font-medium leading-tight",children:H[a].title[X]}),(0,b.jsx)("p",{className:"mt-0.5 text-xs text-muted-foreground leading-snug",children:i(b=>b.welcome_after_onboarding.runtime.cards[a].subtitle)})]})},a)})}),(0,b.jsx)("div",{className:"mt-4 flex justify-end",children:(0,b.jsxs)(k.Button,{size:"lg",disabled:0===E.size||J,onClick:Y,children:[J&&(0,b.jsx)(s.Loader2,{className:"h-4 w-4 animate-spin"}),0===E.size?i(a=>a.welcome_after_onboarding.runtime.assign_empty):i(a=>a.welcome_after_onboarding.runtime.assign_count,{count:E.size})]})})]}),M?(0,b.jsxs)("div",{role:"alert",className:"rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive",children:[(0,b.jsx)("p",{children:M}),(0,b.jsx)(k.Button,{variant:"ghost",size:"sm",className:"mt-1 h-6 px-2 text-xs",onClick:()=>O(null),children:i(a=>a.welcome_after_onboarding.dismiss_error)})]}):null]})})}function S({workspaceId:a,onDismiss:d}){let{t:e,i18n:f}=(0,o.useT)("onboarding"),h=(0,l.useNavigation)(),i=(0,q.useQueryClient)(),m=(0,j.useAuthStore)(a=>a.user),[n,p]=(0,c.useState)(null),[r,s]=(0,c.useState)(!1);if((0,c.useEffect)(()=>{if(!m||n||r)return;let b=!1;return(async()=>{try{var c,d,e;let g,h=I(f.language),j=await P(`${a}:install-runtime`,{title:D[h],description:E[h],status:"in_progress",priority:"high",assignee_type:"member",assignee_id:m.id}),k=await P(`${a}:create-agent-guide`,{title:C[h],description:(c={lang:h,installRuntimeIdentifier:j.identifier,installRuntimeId:j.id},g=`[${c.installRuntimeIdentifier}](mention://issue/${c.installRuntimeId})`,"zh"===c.lang?(d=g,`等运行时上线（见 ${d}）之后，把第一个 agent —— Multica Helper —— 建出来。下面的提示词已经写好，直接复制即可。

## 1. 打开新建 agent 页

在侧边栏点 **Agents** → 点 **New Agent**。

## 2. 选你刚装好的运行时

在 "Runtime" 下选它。如果什么都没有，说明运行时还没上线 —— 先按 ${d} 把安装步骤走完。

## 3. 把下面三段分别复制到对应字段

**名称**
\`\`\`md
${B}
\`\`\`

**描述**
\`\`\`md
${A.zh}
\`\`\`

**指令**
\`\`\`md
${z.zh}
\`\`\`

## 4. 保存 → 分派 issue

点 **Create**。新 agent 会出现在 workspace 的 agent 列表里。

接着创建一个 issue（或把已有 issue 重新分派）→ 把 assignee 设成 Multica Helper → 状态切到 **todo**。运行时会在几秒内接走任务并开始工作。在 issue 的任务面板里看进度。

## 接下来去哪

- **Skills** —— 可复用的指令包，可挂到任何 agent 上。
- **Squads** —— 可一起被分派的一组 agent。
- **Autopilots** —— 定时或 webhook 触发的运行。
- **文档** —— https://multica.ai/docs。`):(e=g,`Once your runtime is online (see ${e}), build your first agent — Multica Helper. The prompt below is pre-written; just copy.

## 1. Open the new-agent screen

Go to **Agents** in the sidebar → click **New Agent**.

## 2. Pick the runtime you just installed

Select the runtime under "Runtime". If nothing shows up, the runtime isn't online yet — finish the install steps in ${e}.

## 3. Copy each block into the matching field

**Name**
\`\`\`md
${B}
\`\`\`

**Description**
\`\`\`md
${A.en}
\`\`\`

**Instructions**
\`\`\`md
${z.en}
\`\`\`

## 4. Save → assign an issue

Hit **Create**. The new agent shows up in the workspace agent list.

Now create an issue (or reassign an existing one) → set assignee = Multica Helper → set status to **todo**. The runtime picks the task up within a few seconds and starts working. Watch progress in the issue's task panel.

## Where to go next

- **Skills** — reusable instruction packs you can attach to any agent.
- **Squads** — groups of agents that can be assigned together.
- **Autopilots** — scheduled or webhook-triggered runs.
- **Docs** — https://multica.ai/docs.`)),status:"todo",priority:"medium",assignee_type:"member",assignee_id:m.id}),l=F[h],n=`${l} [${k.identifier}](mention://issue/${k.id})`;await function(a,b,c){let d=Q.get(a);if(d)return d;let e=t.api.createComment(b,c);return Q.set(a,e),e.finally(()=>{Q.get(a)===e&&Q.delete(a)}).catch(()=>{}),e}(`${a}:install-runtime-followup`,j.id,n),i.invalidateQueries({queryKey:v.issueKeys.all(a)}),b||p({installIssueId:j.id,agentGuideId:k.id})}catch{b||s(!0)}})(),()=>{b=!0}},[n,r,f.language,m,i,e,a]),(0,c.useEffect)(()=>{r&&d()},[r,d]),r||!m)return null;if(!n)return(0,b.jsx)(U,{label:e(a=>a.welcome_after_onboarding.skip.loading)});let u=async()=>{d();let b=await W(i,a);h.push(g.paths.workspace(b).issueDetail(n.installIssueId))};return(0,b.jsx)(w.Dialog,{open:!0,modal:!0,onOpenChange:a=>{a||d()},children:(0,b.jsxs)(w.DialogContent,{className:"max-w-xl sm:max-w-xl","aria-describedby":"welcome-after-onboarding-skip-subtitle",children:[(0,b.jsxs)("div",{className:"flex flex-col items-center gap-4 pt-6",children:[(0,b.jsx)("div",{className:"text-6xl animate-welcome-emoji-pop","aria-hidden":!0,children:"🎉"}),(0,b.jsx)(w.DialogTitle,{className:"text-center text-2xl font-semibold",children:e(a=>a.welcome_after_onboarding.skip.title)}),(0,b.jsx)(w.DialogDescription,{id:"welcome-after-onboarding-skip-subtitle",className:"text-center text-sm text-muted-foreground max-w-md",children:e(a=>a.welcome_after_onboarding.skip.subtitle)})]}),(0,b.jsxs)("div",{className:"mt-6 flex flex-col gap-2",children:[(0,b.jsx)(T,{cardKey:"install_runtime",statusLabel:e(a=>a.welcome_after_onboarding.skip.status_in_progress),statusTone:"active"}),(0,b.jsx)(T,{cardKey:"create_agent",statusLabel:e(a=>a.welcome_after_onboarding.skip.status_todo),statusTone:"todo"})]}),(0,b.jsx)("div",{className:"mt-6 flex justify-end",children:(0,b.jsx)(k.Button,{size:"lg",onClick:u,children:e(a=>a.welcome_after_onboarding.skip.got_it)})})]})})}function T({cardKey:a,statusLabel:c,statusTone:d}){let{t:e}=(0,o.useT)("onboarding");return(0,b.jsx)("div",{className:"flex items-start gap-3 rounded-lg border bg-background px-3 py-2.5",children:(0,b.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,b.jsxs)("div",{className:"flex flex-wrap items-center gap-2",children:[(0,b.jsx)("p",{className:"text-sm font-medium leading-tight",children:e(b=>b.welcome_after_onboarding.skip.cards[a].title)}),(0,b.jsx)("span",{className:(0,x.cn)("rounded-full px-2 py-0.5 text-[11px] font-medium","active"===d?"bg-primary/10 text-primary":"bg-muted text-muted-foreground"),children:c})]}),(0,b.jsx)("p",{className:"mt-1 text-xs text-muted-foreground leading-snug",children:e(b=>b.welcome_after_onboarding.skip.cards[a].subtitle)})]})})}function U({label:a}){return(0,b.jsx)("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm",children:(0,b.jsxs)("div",{className:"flex flex-col items-center gap-3",children:[(0,b.jsx)(s.Loader2,{className:"h-6 w-6 animate-spin text-muted-foreground"}),(0,b.jsx)("p",{className:"text-sm text-muted-foreground",children:a})]})})}function V({title:a,message:c,retryLabel:d,closeLabel:e,onRetry:f,onClose:g}){return(0,b.jsx)("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm",children:(0,b.jsxs)("div",{className:"flex max-w-md flex-col items-center gap-4 rounded-lg border bg-card p-6 shadow-md",children:[(0,b.jsx)(r.AlertCircle,{className:"h-6 w-6 text-destructive"}),(0,b.jsx)("p",{className:"text-center text-sm font-medium text-foreground",children:a}),(0,b.jsx)("p",{className:"text-center text-xs text-muted-foreground",children:c}),(0,b.jsxs)("div",{className:"flex gap-2",children:[(0,b.jsx)(k.Button,{variant:"outline",size:"sm",onClick:g,children:e}),(0,b.jsx)(k.Button,{size:"sm",onClick:f,children:d})]})]})})}async function W(a,b){let c=a.getQueriesData({queryKey:h.workspaceKeys.list()}).map(([,a])=>a).find(Boolean),d=c?.find(a=>a.id===b);return d?d.slug:(await t.api.getWorkspace(b)).slug}var X=a.i(986692);a.s(["default",0,function({children:a,params:k}){var l;let m,{workspaceSlug:n}=(0,c.use)(k),o=(0,j.useAuthStore)(a=>a.user),q=(0,j.useAuthStore)(a=>a.isLoading),r=(0,e.useRouter)();(0,c.useEffect)(()=>{q||o||r.replace(g.paths.login())},[q,o,r]),(0,c.useEffect)(()=>{o&&null==o.onboarded_at&&r.replace(g.paths.onboarding())},[o,r]);let{data:s,isFetched:t}=(0,d.useQuery)({...(0,h.workspaceBySlugOptions)(n),enabled:!!o});s&&(0,i.setCurrentWorkspace)(n,s.id),(0,c.useEffect)(()=>{if(!s||"u"<typeof document)return;let a="https:"===location.protocol?"; Secure":"";document.cookie=`last_workspace_slug=${encodeURIComponent(n)}; path=/; max-age=31536000; SameSite=Lax${a}`},[s,n]);let u=(l=!!s,m=(0,c.useRef)(new Set),l&&n&&m.current.add(n),!!n&&m.current.has(n)),v=(0,b.jsx)("div",{className:"flex h-svh items-center justify-center",children:(0,b.jsx)(X.MulticaIcon,{className:"size-6 animate-pulse"})});return q||!t?v:s?(0,b.jsxs)(f.WorkspaceSlugProvider,{slug:n,children:[a,(0,b.jsx)(J,{})]}):u?null:(0,b.jsx)(p,{})}],403695)}];

//# sourceMappingURL=_worktrees_runtime-config_apps_web_app_%5BworkspaceSlug%5D_layout_tsx_13ufzrn._.js.map