module.exports=[533605,a=>{"use strict";a.s([])}];

//# sourceMappingURL=02hg_apps_web__next-internal_server_app_%28landing%29_about_page_actions_081m0~3.js.map