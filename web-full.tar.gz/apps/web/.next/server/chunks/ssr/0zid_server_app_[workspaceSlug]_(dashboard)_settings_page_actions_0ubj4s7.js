module.exports=[884050,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0zid_server_app_%5BworkspaceSlug%5D_%28dashboard%29_settings_page_actions_0ubj4s7.js.map