module.exports=[137438,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0zid_server_app_%5BworkspaceSlug%5D_%28dashboard%29_skills_page_actions_0ip1x7j.js.map