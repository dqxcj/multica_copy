module.exports=[186166,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0zid_server_app_%5BworkspaceSlug%5D_%28dashboard%29_runtimes_page_actions_0n7kz76.js.map