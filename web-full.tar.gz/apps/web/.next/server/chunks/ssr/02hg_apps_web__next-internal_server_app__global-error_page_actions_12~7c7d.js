module.exports=[478547,a=>{"use strict";a.s([])}];

//# sourceMappingURL=02hg_apps_web__next-internal_server_app__global-error_page_actions_12~7c7d.js.map