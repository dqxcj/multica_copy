module.exports=[604136,a=>a.a(async(b,c)=>{try{var d=a.i(36375),e=a.i(764902),f=a.i(398006),g=b([e]);[e]=g.then?(await g)():g,a.s(["default",0,function(){return(0,d.jsx)(f.ProjectsPage,{})}]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=02hg_apps_web_app_%5BworkspaceSlug%5D_%28dashboard%29_projects_page_tsx_0m5-bee._.js.map