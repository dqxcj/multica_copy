module.exports=[860810,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0zqt_next-internal_server_app_%5BworkspaceSlug%5D_%28dashboard%29_usage_page_actions_0kob28b.js.map