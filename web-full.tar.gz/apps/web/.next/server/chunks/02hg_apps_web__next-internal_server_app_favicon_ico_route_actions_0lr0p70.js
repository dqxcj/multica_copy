module.exports=[955866,s=>{"use strict";s.s([])}];

//# sourceMappingURL=02hg_apps_web__next-internal_server_app_favicon_ico_route_actions_0lr0p70.js.map