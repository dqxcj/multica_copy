globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/CCRW2BlCzuz_uDCS02gq4/_buildManifest.js",
    "static/CCRW2BlCzuz_uDCS02gq4/_ssgManifest.js",
    "static/CCRW2BlCzuz_uDCS02gq4/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0dp9c_9ft2l~m.js",
    "static/chunks/0i.-muiq~6db7.js",
    "static/chunks/09j1-xi84w~93.js",
    "static/chunks/0uobui~boawi-.js",
    "static/chunks/0xn.j6ysos99t.js",
    "static/chunks/turbopack-0yscplgz-91zj.js"
  ]
};
