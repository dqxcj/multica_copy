var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0-rr0ze._.js")
R.c("server/chunks/[root-of-the-server]__13jijs0._.js")
R.m(419222)
module.exports=R.m(419222).exports
